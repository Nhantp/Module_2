package ss7_Abstract_class_and_interface.bai_tap.Resizeable;

public interface Resizeable {
     void resize(double percent);
}
