package ss7_Abstract_class_and_interface.bai_tap.Colorable;

public class main {
    public static void main(String[] args) {
     Square square=new Square(1);
     square.howToColor();
        System.out.println(square);
     Square1 square1=new Square1(2);
        System.out.println("\n"+square1);
    }

}
