package ss7_Abstract_class_and_interface.bai_tap.Colorable;

public interface Colorable {
    void howToColor();
}
