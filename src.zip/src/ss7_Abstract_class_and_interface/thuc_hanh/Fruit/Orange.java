package ss7_Abstract_class_and_interface.thuc_hanh.Fruit;
import ss7_Abstract_class_and_interface.thuc_hanh.Fruit.edible;

public class Orange extends Fruit {
    @Override
    public String howToEat() {
        return "Orange could be juiced";
    }
}
