package ss7_Abstract_class_and_interface.thuc_hanh.Fruit;

public interface edible {
    String howToEat();
}
