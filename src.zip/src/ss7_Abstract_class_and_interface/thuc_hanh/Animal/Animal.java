package ss7_Abstract_class_and_interface.thuc_hanh.Animal;

public abstract class Animal {
    public abstract String makeSound();
}
