package ss7_Abstract_class_and_interface.thuc_hanh.Animal;

public class Tiger extends Animal {
    @Override
    public String makeSound() {
        return "Tiger: roarrr";
    }
}
