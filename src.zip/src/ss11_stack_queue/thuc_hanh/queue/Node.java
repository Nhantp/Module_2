package ss11_stack_queue.thuc_hanh.queue;

public class Node {
    public int key;
    public Node next;

    public Node(int key) {
        this.key = key;
        this.next = null;
    }
}
