package ss5_AccessModifier_StaticMethod.bai_tap;

public class Test {
    public static void main(String[] args) {
        Student student=new Student();
        String name="Nhan";
        String classes="1";
        student.setName(name);
        student.setClasses(classes);
    }
}
