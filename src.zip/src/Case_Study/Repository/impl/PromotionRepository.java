package Case_Study.Repository.impl;

public class PromotionRepository {
}
