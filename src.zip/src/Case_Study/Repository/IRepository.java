package Case_Study.Repository;

import java.util.List;

public interface IRepository<E> {
    void add(E e);
    void display();
}
