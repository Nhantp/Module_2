package Case_Study.Service;

public interface IPromotionService {
}
