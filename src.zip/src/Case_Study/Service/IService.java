package Case_Study.Service;

public interface IService {
    void add();
    void display();
}
