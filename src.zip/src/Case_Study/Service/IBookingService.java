package Case_Study.Service;

public interface IBookingService {

   void addBooking();
   void displayBooking();

}
