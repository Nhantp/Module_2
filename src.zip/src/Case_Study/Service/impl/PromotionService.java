package Case_Study.Service.impl;

public class PromotionService {
}
