package ss10_danh_sach.bai_tap;

import ss11_stack_queue.thuc_hanh.queue.Node;

public class MyLinkedList<E> {
    private Node head;
    int numNodes;
    class Node{
        private Node next;
        Object data;

        public Node(Object data){

        }
    }
}
