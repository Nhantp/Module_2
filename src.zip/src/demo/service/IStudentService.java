package demo.service;

public interface IStudentService {
    void addStudent();

    void display();
}
