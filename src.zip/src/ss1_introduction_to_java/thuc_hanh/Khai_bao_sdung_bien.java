package ss1_introduction_to_java.thuc_hanh;
public class Khai_bao_sdung_bien {
    public static void main(String[] args) {
        int i=10;
        float f=20.5f;
        double d=20.5;
        boolean b=true;
        char c='a';
        String s="Da Nang";
         System.out.println("i="+i);
         System.out.println("f="+f);
         System.out.println("d="+d);
         System.out.println("b="+b);
         System.out.println("c="+c);
         System.out.println("s="+s);
    }
}
