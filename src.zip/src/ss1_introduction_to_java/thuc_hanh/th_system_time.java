package ss1_introduction_to_java.thuc_hanh;

import java.util.Date;
public class th_system_time {
    public static void main(String[] args) {
        Date now =new Date();
       System.out.println("Now is:"+now);
    }
}
