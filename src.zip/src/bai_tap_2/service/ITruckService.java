package bai_tap_2.service;

public interface ITruckService {
    void addTruck();

    void displayTruck();

    void searchTruck(String bienSoXe);

}
