package bai_tap_2.service;

public interface IMotoBikeService {
    void displayMotoBike();

    void addMotoBike();
    void searchMotoBike(String bienSoXe);
}
