package ss15_exception.bai_tap;

public class TriangleException extends Exception{
    public TriangleException(String str){
        super(str);
    }
}
