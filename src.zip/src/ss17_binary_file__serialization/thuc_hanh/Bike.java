package ss17_binary_file__serialization.thuc_hanh;

abstract class Bike {
    public abstract void run();
    void changeGear(){
        System.out.println("gear changed");
    }
}

