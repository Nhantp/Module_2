package Case_Study.Repository;

public interface IPromotionRepository {
}
