package Case_Study.Service;

public interface IContractService extends IService {
    @Override
    void add();

    @Override
    void display();
}
